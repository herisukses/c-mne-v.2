
<!DOCTYPE html>

<html lang="en">
<!-- Mirrored from hashing24.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 10 Dec 2017 16:47:20 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
        <meta charset="utf-8">
        <meta name="okpay-verification" content="048b23c7-05fd-4d06-9871-8edaceb33391" />
        <meta name="yandex-verification" content="6863280f28b10b18" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Start Mining with Maximum Efficiency</title>
        <meta name="keywords" content="
bitcoin, blockchain, mining, bitfury, bitfury.com, hashing24, hashing24.com, how to mine bitcoin, mine, cloud mining, bitcoin cloud mining, bitcoin farming, bitcoin mining sites, online bitcoin miner, bitcoin mining how it works, best bitcoin mining, " />
        <meta name="description" content="Hashing24 provides turnkey renting solutions from the largest bitcoin mining data centers. 100% uptime guarantee!" />

        <link href="bootstrap-3.1.1/css/bootstrap.css" rel="stylesheet" />
        <link href="jquery-ui-1.10.4/css/redmond/jquery-ui-1.10.4.custom.css" rel="stylesheet" />
        <link href="css/jquery.bootstrap-touchspin.min.css" rel="stylesheet" />
        <link href="css/font-awesome.min.css" rel="stylesheet" />
        <link href="css/commonc55e.css?rev=97" rel="stylesheet" />
        <link href="css/animationsc55e.css?rev=97" rel="stylesheet" />
        <link href="css/printc55e.css?rev=97" rel="stylesheet" />
        <link href="css/tmpc55e.css?rev=97" rel="stylesheet" />
        <link href="css/bootstrap-slider.min.css" rel="stylesheet" />
        <!--<link href="css/slider.css" rel="stylesheet" />-->
        <!--<link href="css/pips.css" rel="stylesheet" />-->

        

        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

        <script src="js/jquery.js"></script>
        <script src="bootstrap-3.1.1/js/bootstrap.js"></script>
        <script src="js/moment.js"></script>
        <script src="js/bootstrap-notify.js"></script>
        <script src="jquery-ui-1.10.4/js/jquery-ui-1.10.4.custom.min.js"></script>
        <script src="js/jquery.bootstrap-touchspin.min.js"></script>
        <script src="js/jquery.ui.touch-punch.js"></script>
        <script src="js/jquery.cookie.js"></script>
        <script src="js/bootstrap-tooltip.js"></script>
        <script src="js/polyfill.js"></script>
        <script src="js/clipboard.min.js"></script>
        <script src="js/jquery.validate.min.js"></script>
        <script src="js/bignumber.min.js"></script>
        <script src="js/bootstrap-slider.js"></script>
        <script src="../www.google.com/recaptcha/api2633.js?onload=onloadRCCallback&amp;render=explicit&amp;hl=en" async defer></script>

        <script>
        var RCs = ['registerRC', 'supportRC', 'partnersRC', 'authRC', 'helpRC'],
            RCids = {};
        var onloadRCCallback = function() {
            RCs.forEach(function(rc) {
                if ( document.getElementById(rc) ) {
                    RCids[rc] = grecaptcha.render(rc, {
                        'sitekey' : '6Lf-tzMUAAAAAGtf_pw_wsolTKqAqifJ7MYsqPmT'
                    });
                }
            });
        };
        </script>

        <script>

var
BO2FO_CONVERT_MULTIPLIER = 1000;

</script>


        <script src="common/commonc55e.js?rev=97"></script>
        <script src="js/commonc55e.js?rev=97"></script>

        

        <!– Facebook Pixel Code –>
<script>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','../connect.facebook.net/en_US/fbevents.js');
fbq('init', '269296810123565');
fbq('track', "PageView");
</script>
<noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=269296810123565&amp;ev=PageView&amp;noscript=1"/></noscript>
<!– End Facebook Pixel Code –>

    </head>
    <body>
        <!– Google Tag Manager –>
<noscript><iframe src="http://www.googletagmanager.com/ns.html?id=GTM-TMKS39"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'../www.googletagmanager.com/gtm5445.html?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-TMKS39');</script>
<!– End Google Tag Manager –>



            <div class="page">
                



<div class="device-xs visible-xs"></div>
<div class="device-sm visible-sm"></div>
<div class="device-md visible-md"></div>
<div class="device-lg visible-lg"></div>

<div class="print-logo hidden print-visible"><img alt="Hashing24" width="250" src="i/hashing-logo.png"></div>

<nav class="navbar navbar-static-top navbar-inverse">
	<div class="container">
        
<div class="dropdown dropdown-language pull-right">
    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
        <span class="icon"><img alt="en" src="i/flag_en.svg"><span class="hidden-md hidden-sm hidden-xs"> English</span></span>
    </a>
    <ul class="dropdown-menu">
        <li>
            <a class="j-change-lang" lang="ch" href="index.php">
                <img alt="ch" src="i/flag_ch.svg"><span class="hidden-md hidden-sm hidden-xs"> Chinese</span>
            </a>
        </li>
        <li>
            <a class="j-change-lang" lang="en" href="index.php">
                <img alt="en" src="i/flag_en.svg"><span class="hidden-md hidden-sm hidden-xs"> English</span>
            </a>
        </li>
        <li>
            <a class="j-change-lang" lang="es" href="index.php">
                <img alt="es" src="i/flag_es.svg"><span class="hidden-md hidden-sm hidden-xs"> Spanish</span>
            </a>
        </li>
        <li>
            <a class="j-change-lang" lang="ind" href="index.php">
                <img alt="ind" src="i/flag_ind.svg"><span class="hidden-md hidden-sm hidden-xs"> Indonesian</span>
            </a>
        </li>
        <li>
            <a class="j-change-lang" lang="jp" href="index.php">
                <img alt="jp" src="i/flag_jp.svg"><span class="hidden-md hidden-sm hidden-xs"> Japanese</span>
            </a>
        </li>
        <li>
            <a class="j-change-lang" lang="lo" href="index.php">
                <img alt="lo" src="i/flag_lo.svg"><span class="hidden-md hidden-sm hidden-xs"> Laotian</span>
            </a>
        </li>
        <li>
            <a class="j-change-lang" lang="ru" href="index.php">
                <img alt="ru" src="i/flag_ru.svg"><span class="hidden-md hidden-sm hidden-xs"> Russian</span>
            </a>
        </li>
        <li>
            <a class="j-change-lang" lang="th" href="index.php">
                <img alt="th" src="i/flag_th.svg"><span class="hidden-md hidden-sm hidden-xs"> Thai</span>
            </a>
        </li>
        <li>
            <a class="j-change-lang" lang="vn" href="index.php">
                <img alt="vn" src="i/flag_vn.svg"><span class="hidden-md hidden-sm hidden-xs"> Vietnamese</span>
            </a>
        </li>
    </ul>
</div>

<script>
function changeLang() {
    $.cookie('lang', $(this).attr('lang'), { path: '/' });
}

$('.j-change-lang').click(changeLang);
</script>

		<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#top-navbar-collapse">
			<span class="sr-only">Toggle Navigation</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			</button>
			<a class="navbar-brand" href="index.php"><img alt="Hashing24" src="i/hashing-logo.png"></a>
		</div>
	    <div class="collapse navbar-collapse" id="top-navbar-collapse">
            <ul class="nav navbar-nav navbar-right cc-nav">
                <li class="margin-right-12"><a href="faq.php">FAQ</a></li>
                <li class="margin-right-12"><a href="about.php">About Us</a></li>
                <li class="margin-right-12"><a href="howitworks.php">How it Works</a></li>
                <li class="margin-right-12"><a href="tariffs.php">Plans</a></li>

                <!--<li class="margin-right-12"><a href="calculator.php">Calculator</a></li>-->

			        <li class="margin-right-12"><div class="margin-top-10"><a href="register.php" class="navbar-btn btn btn-warning btn-sm margin-left-12">Register an Account</a></div></li>
			        <li class="margin-right-12"><a href="#" class="navbar-link" data-toggle="modal" data-target="#signInModal"><small class="white">Sign In</small></a></li>
	        </ul>
	    </div>
	</div>
</nav>


<div class="container common_information clearfix margin-top-8">
	<div class="small-top-info">
		<div class="row">
			<div class="col-md-8 col-xs-12">
                <ul class="list-inline pull-left">

                <li class="margin-right-10">Price: </li>
				<li class="margin-right-10">
                    BTC/USD<span>:
			<?php
                       
			$f="https://api.coindesk.com/v1/bpi/currentprice.json";

			$file=file_get_contents($f);
			
			if($file==""){
	print("error:cant get file");
	return;
}
$myjson = json_decode($file);

print $myjson->bpi->USD->rate; ?>
								
</span>
</li>
               <!-- <li class="margin-right-10">
                    BTC/USD <span>15453.7263</span>
                </li>-->
                <li class="margin-right-10">
                    BTC/EUR <span>:	<?php
                       
			$f="https://api.coindesk.com/v1/bpi/currentprice.json";

			$file=file_get_contents($f);
			
			if($file==""){
	print("error:cant get file");
	return;
}
$myjson = json_decode($file);

print $myjson->bpi->EUR->rate; ?></span>
                </li>
                <li class="margin-left-15 margin-right-15 hidden-xs">Difficulty: <span>
 <?php
  $text = file_get_contents("https://blockchain.info/q/getdifficulty");
  echo $text;
  ?>  </span></li>
               <!-- <li class="margin-right-15 hidden-xs">Hashrate: <span>13760 PH/s</span></li>-->

				</ul>
			</div>

			<div class="col-md-4 col-xs-12">
			</div>
		</div>
	</div>
</div>

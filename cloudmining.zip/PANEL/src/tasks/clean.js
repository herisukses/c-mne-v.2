module.exports = {
  dist: 'dist',
  public: 'public'
};

<?php

?>

<footer>
    <div class="container">
        <div class="row">
            <div class="col-md-offset-2 col-md-8 col-sm-offset-1 col-sm-10">
                <div class="row">
                    <div class="col-sm-4 footer-col">
                        <p><a href="index.php">Home</a><p>
                        <p><a href="about.php">About Us</a></p>
                        <p><a href="howitworks.php">How it Works</a></p>
                        <p><a href="tariffs.php">Plans</a></p>
                    </div>
                    <div class="col-sm-4 footer-col">
                       <!-- <p><a href="whyus.php">Why Hashing24</a></p>-->
                        <p><a href="register.php">Register an Account</a></p>
                        <p><a href="partners.php">Partners</a></p>
                        <p><a href="support.php">Support</a></p>
                    </div>
                    <div class="col-sm-4 footer-col">

                        <p><a href="terms.php">Terms &amp; Conditions</a></p>
                        <p><a href="privacy.php">Privacy Policy</a></p>
                        <p><a href="aml_kyc_policy.php">AML/KYC Policy</a></p>
                        <p><a href="disclaimer.php">Disclaimer</a></p>
                        
                    </div>
                </div>
            </div>
            <div class="col-md-2 col-sm-12">
                <div class="footer-icons">
                    <a href="#" class="footer-fb" target=""><img src="i/fb29.png" alt="Facebook Hashing24 Page"  disabled/></a>
                    <img alt="Comodo" class="icon-comodo" src="i/icon_comodo.png"/>
                </div>
            </div>
        </div>
        <div class="payments-block text-center">
<!--           <img src="i/payments/mastercard_secure.png" alt="Mastercard Secure" hidden>
			<img src="i/payments/mastercard.png" alt="Mastercard" hidden>
			 <img src="bitcoin-logo-DDAEEA68FA-seeklogo.com.png" alt="Bitcoin" width="45px">-->
                         <img src="RSS bitcoin accepyed here.jpg" alt="ehter" width="100px" >
<!--            <img src="1 zna2Zw5JDDnP499Zo3WBQg.png" alt="Dash logo" width="45px">
            <img src="i/payments/maestro.png" alt="Maestro" hidden>-->
        </div>
        <div style="display: none;"><a target="_blank" rel="nofollow" href="https://www.couponchief.com/hashing24">Hashing24.com Coupons</a></div>
        <p class="margin-top-15 copy text-center"><small>We donot Provide Services for US Residents.</small></p>
        <p class="margin-top-15 copy text-center"><small>© 2015&mdash;2017 NEWSTAR L.P. (UK). All rights reserved.</small></p>
    </div>
</footer>

<?Php
 setcookie("CML", "ru", 0x7FFFFFFF ,'/');
 header('Location:../');
?>
<?Php
mysql_connect ("localhost","db user","db pass");
mysql_select_db ("db name");
?>
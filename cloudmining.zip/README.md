# cloudmining
A basic project implementation for cloud mining  (testing only do not clone its useless for you)
